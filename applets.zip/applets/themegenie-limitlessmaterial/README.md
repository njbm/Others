## TODO 
- Apply caching mechanizm for core-configs and refactor favicon and title class
- Create installer 
- Remove default laravel migration files