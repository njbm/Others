<?php

namespace Themegenie\LimitlessMaterial\Contracts;

interface ILayout 
{


}
