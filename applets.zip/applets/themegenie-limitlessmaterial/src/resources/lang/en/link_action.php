<?php

return [
    "Create" => "C R E A T E IIIII :entity",
];