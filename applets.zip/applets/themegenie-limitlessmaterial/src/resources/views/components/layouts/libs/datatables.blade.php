<!-- Datatable files -->
<script id="datatables" src="{{ asset('') }}global_assets/js/plugins/tables/datatables/datatables.min.js"></script>
<script id="datatables_advanced" src="{{ asset('') }}global_assets/js/demo_pages/datatables_advanced.js"></script>
<script id="datatables_basic" src="{{ asset('') }}global_assets/js/demo_pages/datatables_basic.js"></script>
<script id="select2" src="{{ asset('') }}global_assets/js/plugins/forms/selects/select2.min.js"></script>


<!-- Theme JS files -->
<script id="d3" src="{{ asset('') }}global_assets/js/plugins/visualization/d3/d3.min.js"></script>
<script id="d3_tooltip" src="{{ asset('') }}global_assets/js/plugins/visualization/d3/d3_tooltip.js"></script>
<script id="switchery" src="{{ asset('') }}global_assets/js/plugins/forms/styling/switchery.min.js"></script>
<script id="moment" src="{{ asset('') }}global_assets/js/plugins/ui/moment/moment.min.js"></script>
<script id="daterangepicker" src="{{ asset('') }}global_assets/js/plugins/pickers/daterangepicker.js"></script>
