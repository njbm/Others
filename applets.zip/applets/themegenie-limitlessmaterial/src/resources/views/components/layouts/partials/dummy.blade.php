dummy partial
