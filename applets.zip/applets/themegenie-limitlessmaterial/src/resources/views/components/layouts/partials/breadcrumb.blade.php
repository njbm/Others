<div class="breadcrumb">
    <a href="#" class="breadcrumb-item">
        <i class="icon-home2 mr-2"></i>
            BC
    </a>
</div>
