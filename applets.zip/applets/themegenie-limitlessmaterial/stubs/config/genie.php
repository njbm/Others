<?php

return [
  'theme' => 'LimitlesMaterial',
  'db.favicon' => false,
  'db.title' => false
];